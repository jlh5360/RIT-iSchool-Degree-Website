# External UI React components that extend and add to my project

App:

    -  Navigation Bar --> Dropdown component

About (DONE)

Degrees (DONE) --> Accordion component

Minors (DONE):
    -  Accordion component
    -  Modal component
    -  Button component

Employment (DONE):
    -  Card component
    -  Professional Employment Table - Data Grid component
    -  Co-op Table - Data Grid component

People (done):
    -  Tabs component
    -  Modal component
    -  Button component (variant="outlined")


Notes:

    -  Made it look similar to RIT website

    -  Added the RIT website favicon and RIT Golisano College of Computing and Information Sciences logo

    -  Added a navigation bar the jumps to a specific section of the webpage using custom JavaScripts

    -  Added/rebuilt a custom webpage progress bar similar to RIT website that shows a visual progression of the user's location of the webpage
